
package com.example.melanoretectai;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Pair;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.example.melanoretectai.model.CancerDetectionModel;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.yalantis.ucrop.UCrop;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "CancerDetectionApp";
FirebaseAuth firebaseAuth;
FirebaseUser firebaseUser;
    // UI Components
    private TextView txtProbBenign, txtPredictedClass, txtConfidence;
    private TableLayout tableLayout;
    private ImageView imageView;
    private Button btnPickImage, btnCaptureImage, btnDetectNow, btnRetry;

    // Image Handling
    private static Bitmap img;

    // Permission Constants
    private static final int REQUEST_CAMERA_PERMISSION = 1;
    private static final int REQUEST_STORAGE_PERMISSION = 2;

    // Activity Launchers
    private ActivityResultLauncher<Intent> mImagePickerLauncher;
    private ActivityResultLauncher<Intent> mCameraLauncher;

    // Cancer Detection Model
    private CancerDetectionModel cancerDetectionModel;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainActivity), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initializeViews();

        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
// Load animations
        Animation alphaAnimation = AnimationUtils.loadAnimation(this, R.anim.alpha);
        Animation rotateAnimation = AnimationUtils.loadAnimation(this, R.anim.rotate);
        Animation translateAnimation = AnimationUtils.loadAnimation(this, R.anim.translate);
        Animation scaleAnimation = AnimationUtils.loadAnimation(this, R.anim.scale);
        Animation combinationAnimation = AnimationUtils.loadAnimation(this, R.anim.combination);


        // Apply animations
        btnDetectNow.startAnimation(translateAnimation);
        btnCaptureImage.startAnimation(scaleAnimation);
        btnPickImage.startAnimation(alphaAnimation);
        btnRetry.startAnimation(combinationAnimation);
        imageView.startAnimation(rotateAnimation);


        // Set click listeners to apply scale animation
        btnDetectNow.setOnClickListener(v -> v.startAnimation(scaleAnimation));
        btnCaptureImage.setOnClickListener(v -> v.startAnimation(scaleAnimation));
        btnPickImage.setOnClickListener(v -> v.startAnimation(scaleAnimation));
        btnRetry.setOnClickListener(v -> v.startAnimation(scaleAnimation));


// Apply the animation to the buttons
btnDetectNow.startAnimation(fadeIn);
        btnCaptureImage.startAnimation(fadeIn);
btnPickImage.startAnimation(fadeIn);
btnRetry.startAnimation(fadeIn);

        initializeModel();
        requestPermissionsIfNecessary();
        setupButtonListeners();
        setupActivityLaunchers();

        if(firebaseUser == null){
            startActivity(new Intent(MainActivity.this, Login.class));
            finish();
        }

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // Handle the back button press
                finish();
            }
        });
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(this, R.color.custom_toolbar_color)));


    }

    // Inflate the menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    // Handle menu item clicks
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            firebaseAuth.signOut();
            Toast.makeText(this, "Logging out...", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(MainActivity.this, Login.class));
            return true;
        }
//        if (item.getItemId() == R.id.action_history) {
//            // Handle the "About" action
//            Toast.makeText(this, "History clicked", Toast.LENGTH_SHORT).show();
//            return true;
//        }
        return super.onOptionsItemSelected(item);
    }



private void initializeViews() {
        tableLayout = findViewById(R.id.tblView);
        btnCaptureImage = findViewById(R.id.btnCaptureImg);
        btnPickImage = findViewById(R.id.btnPickImage);
        btnRetry = findViewById(R.id.btnRetry);
        imageView = findViewById(R.id.displayImg);
        btnDetectNow = findViewById(R.id.btnDetectNow);
        txtPredictedClass = findViewById(R.id.txtPredication);
        txtConfidence = findViewById(R.id.txtConfidence);
    }

    private void initializeModel() {
        if(firebaseUser != null){
            cancerDetectionModel = new CancerDetectionModel(this, "skin_model.tflite");
        }
    }

    private void setupButtonListeners() {
        btnDetectNow.setOnClickListener(view -> handleDetection());
        btnRetry.setOnClickListener(view -> restartActivity());

        btnPickImage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            mImagePickerLauncher.launch(intent);
        });

        btnCaptureImage.setOnClickListener(v -> {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            mCameraLauncher.launch(intent);
        });
    }

    private void setupActivityLaunchers() {
        mImagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Uri uri = result.getData().getData();
                        startCrop(uri);
                    }
                });

        mCameraLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Bundle extras = result.getData().getExtras();
                        img = (Bitmap) extras.get("data");
                        startCrop(getImageUri(img));
                    }
                });
    }

    private void startCrop(Uri sourceUri) {
        Uri destinationUri = Uri.fromFile(new File(getCacheDir(), "croppedImage.jpg"));

        UCrop.Options options = new UCrop.Options();
        options.setFreeStyleCropEnabled(true);
        options.setToolbarTitle("Crop Image");
        options.setCompressionFormat(Bitmap.CompressFormat.JPEG);
        options.setCompressionQuality(100);

        UCrop.of(sourceUri, destinationUri)
                .withOptions(options)
                .useSourceImageAspectRatio()
                .withMaxResultSize(3000, 3000)
                .start(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == UCrop.REQUEST_CROP) {
            if (resultCode == RESULT_OK) {
                Uri croppedUri = UCrop.getOutput(data);
                try {
                    InputStream inputStream = getContentResolver().openInputStream(croppedUri);
                    img = BitmapFactory.decodeStream(inputStream);
                    imageView.setImageBitmap(img);
                    Toast.makeText(this, "Image cropped successfully", Toast.LENGTH_SHORT).show();
                } catch (FileNotFoundException e) {
                    Log.e(TAG, "Error loading cropped image: " + e.getMessage());
                }
            } else if (resultCode == UCrop.RESULT_ERROR) {
                Throwable cropError = UCrop.getError(data);
                Log.e(TAG, "Crop error: " + cropError.getMessage());
                Toast.makeText(this, "Crop failed: " + cropError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private Uri getImageUri(Bitmap inImage) {
        String path = MediaStore.Images.Media.insertImage(getContentResolver(), inImage, "title", null);
        return Uri.parse(path);
    }

    private void handleDetection() {
        if (img != null && cancerDetectionModel != null) {
            // Hide unnecessary buttons and show relevant UI elements
            btnCaptureImage.setVisibility(View.GONE);
            btnPickImage.setVisibility(View.GONE);
            btnDetectNow.setVisibility(View.GONE);
            btnRetry.setVisibility(View.VISIBLE);
            tableLayout.setVisibility(View.VISIBLE);

            try {
                // Get the prediction result (probabilities and predicted label)
                Pair<float[], String> predictionResult = cancerDetectionModel.predictCancer(img);
                float[] probabilities = predictionResult.first;
                String predictedLabel = predictionResult.second;

                Log.d(TAG, "Prediction Label: " + predictedLabel);

                // Initialize highest probability and class index
                float highestProb = -1;
                int highestProbIndex = -1;

                // Find the index with the highest probability
                for (int i = 0; i < probabilities.length; i++) {
                    if (probabilities[i] > highestProb) {
                        highestProb = probabilities[i];
                        highestProbIndex = i;
                    }
                }

                // Define the class labels based on your model's output
                String[] classLabels = {
                        "Actinic Keratosis (Malignant)",
                        "Basal Cell Carcinoma (Malignant)",
                        "Seborrheic Keratosis (Benign)",
                        "Dermatofibroma (Benign)",
                        "Nevus (Benign)",
                        "Vascular Lesion (Benign)",
                        "Melanoma (Malignant)"
                };

                // Display the predicted label and probability (Confidence)
                if (highestProbIndex >= 0 && highestProbIndex < classLabels.length) {
                    String classLabel = classLabels[highestProbIndex];
                    String result = classLabel.contains("Malignant") ? "Malignant" : "Benign";
                    txtPredictedClass.setText(result);

                    // Set the "Prediction" and "Confidence" on the UI
//                    txtPredictedClass.setText( classLabel);

                    // Display the formatted probability as a percentage
                    String probabilityText = String.format("%.2f", highestProb * 100) + "%";
                    txtConfidence.setText( probabilityText);
                }
            } catch (Exception e) {
                // Handle errors that occur during prediction
                Log.e(TAG, "Prediction Error: " + e.getMessage());
                Toast.makeText(this, "Error during prediction: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            // Handle case where no image is available
            Toast.makeText(this, "No image available for prediction", Toast.LENGTH_SHORT).show();
        }
    }


    private void restartActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void requestPermissionsIfNecessary() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        }
    }


}
