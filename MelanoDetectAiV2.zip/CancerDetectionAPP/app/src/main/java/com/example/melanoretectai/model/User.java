package com.example.melanoretectai.model;

/**
 * Represents a User with a unique identifier (UID), email, and password.
 */
public class User {
    private String UID;
    private String email;
    private String password;

    /**
     * Default constructor for creating an empty User object.
     */
    public User() {
    }

    /**
     * Constructor for creating a User object with specified UID, email, and password.
     *
     * @param UID      the unique identifier for the user
     * @param email    the email address of the user
     * @param password the password of the user
     */
    public User(String UID, String email, String password) {
        this.UID = UID;
        this.email = email;
        this.password = password;
    }

    /**
     * Gets the unique identifier of the user.
     *
     * @return the UID of the user
     */
    public String getUID() {
        return UID;
    }

    /**
     * Sets the unique identifier of the user.
     *
     * @param UID the new UID of the user
     */
    public void setUID(String UID) {
        this.UID = UID;
    }

    /**
     * Gets the email address of the user.
     *
     * @return the email of the user
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address of the user.
     *
     * @param email the new email of the user
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the password of the user.
     *
     * @return the password of the user
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password of the user.
     *
     * @param password the new password of the user
     */
    public void setPassword(String password) {
        this.password = password;
    }
}