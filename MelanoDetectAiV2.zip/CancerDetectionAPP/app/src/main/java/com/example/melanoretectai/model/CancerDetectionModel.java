package com.example.melanoretectai.model;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.Pair;
import android.widget.Toast;




import org.tensorflow.lite.Interpreter;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;
import java.util.concurrent.Executors;

public class CancerDetectionModel {
    private Interpreter tflite;
    private Context context;
    private int modelInputWidth = 224;
    private int modelInputHeight = 224;
    private int modelInputChannels = 3;

    private static final String TAG = "CancerDetectionModel";


    private static final String[] CLASS_NAMES = {
            "Actinic Keratosis", "Basal Cell Carcinoma", "Seborrheic Keratosis",
            "Dermatofibroma", "Nevus", "Vascular Lesion", "Melanoma"
    };

    private static final String[] CATEGORIES = {
            "Malignant", "Malignant", "Benign", "Benign", "Benign", "Benign", "Malignant"
    };
    public CancerDetectionModel(Context context, String modelFileName) {
        this.context = context;
        try {
            Log.d(TAG, "Initializing model...");
            loadModelAsync(modelFileName);
        } catch (Exception e) {
            Log.e(TAG, "Unexpected error: " + e.getMessage(), e);
            Toast.makeText(context, "Unexpected error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void loadModelAsync(String modelFileName) {
        Log.d(TAG, "Start loading model asynchronously...");
        ProgressDialog progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Loading model...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                Log.d(TAG, "Attempting to load model file: " + modelFileName);
                MappedByteBuffer model = loadModelFile(context, modelFileName);

                new Handler(Looper.getMainLooper()).post(() -> {
                    progressDialog.dismiss();
                    if (model != null) {
                        tflite = new Interpreter(model);
                        Log.d(TAG, "Model loaded successfully");
                        int[] inputShape = tflite.getInputTensor(0).shape();
                        modelInputWidth = inputShape[1];
                        modelInputHeight = inputShape[2];
                        modelInputChannels = inputShape[3];
                        Toast.makeText(context, "Model loaded successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.e(TAG, "Model loading failed: model is null");
                        Toast.makeText(context, "Failed to load model", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (IOException e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    progressDialog.dismiss();
                    Toast.makeText(context, "Error loading model", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private MappedByteBuffer loadModelFile(Context context, String modelPath) throws IOException {
        AssetFileDescriptor fileDescriptor = context.getAssets().openFd(modelPath);
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }

public Pair<float[], String> predictCancer(Bitmap bitmap) {
    if (tflite == null) {
        Log.e(TAG, "Interpreter is not initialized");
        Toast.makeText(context, "Model not loaded", Toast.LENGTH_SHORT).show();
        return null;
    }

    try {
        Log.d(TAG, "Running inference...");

        // Prepare the input bitmap
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, modelInputWidth, modelInputHeight, true);
        Log.d(TAG, "Original Bitmap Dimensions: Width = " + bitmap.getWidth() + ", Height = " + bitmap.getHeight());
        Log.d(TAG, "Resized Bitmap Dimensions: Width = " + resizedBitmap.getWidth() + ", Height = " + resizedBitmap.getHeight());

        ByteBuffer inputBuffer = bitmapToByteBuffer(resizedBitmap);

        // Define output shape based on the model's output
        float[][] output = new float[1][CLASS_NAMES.length];  // Update to match the number of classes
        Log.d(TAG, "Output shape: " + Arrays.toString(tflite.getOutputTensor(0).shape()));

        // Run inference
        tflite.run(inputBuffer, output);

        // Get the prediction result
        float[] probabilities = output[0];
        int classIndex = getMaxIndex(probabilities);
        String className = CLASS_NAMES[classIndex];
        String category = CATEGORIES[classIndex];
        float confidence = probabilities[classIndex] * 100;

        // Log prediction details
        Log.d(TAG, "Predicted Class: " + className);
        Log.d(TAG, "Category: " + category);
        Log.d(TAG, "Confidence: " + String.format("%.2f", confidence) + "%");
        Log.d(TAG, "Raw model output: " + Arrays.toString(probabilities));

        // Return the prediction result with probabilities and predicted label
        return new Pair<>(probabilities, className);
    } catch (Exception e) {
        Log.e(TAG, "Error during inference: " + e.getMessage(), e);
        Toast.makeText(context, "Error during inference: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        return null;
    }
}

    // Helper method to find the index of the highest probability
    private int getMaxIndex(float[] probabilities) {
        int index = 0;
        for (int i = 1; i < probabilities.length; i++) {
            if (probabilities[i] > probabilities[index]) {
                index = i;
            }
        }
        return index;
    }



    private ByteBuffer bitmapToByteBuffer(Bitmap bitmap) {
        // Scale bitmap to the model's input size
        Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, modelInputWidth, modelInputHeight, true);

        // Log the shape after scaling
        Log.d("Preprocess", "Scaled Bitmap Shape: " + scaledBitmap.getWidth() + "x" + scaledBitmap.getHeight());

        // Prepare ByteBuffer for model input
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4 * modelInputWidth * modelInputHeight * modelInputChannels);
        byteBuffer.order(ByteOrder.nativeOrder());

        // Get pixel values
        int[] intValues = new int[modelInputWidth * modelInputHeight];
        scaledBitmap.getPixels(intValues, 0, modelInputWidth, 0, 0, modelInputWidth, modelInputHeight);

        // Normalize and store pixels in ByteBuffer
        int pixelIndex = 0;
        for (int y = 0; y < modelInputHeight; y++) {
            for (int x = 0; x < modelInputWidth; x++) {
                int pixel = intValues[pixelIndex++];
                float r = ((pixel >> 16) & 0xFF) / 255.0f; // Red
                float g = ((pixel >> 8) & 0xFF) / 255.0f;  // Green
                float b = (pixel & 0xFF) / 255.0f;         // Blue

                byteBuffer.putFloat(b); // Blue
                byteBuffer.putFloat(g); // Green
                byteBuffer.putFloat(r); // Red
            }
        }

        return byteBuffer;
    }





    public void close() {
        if (tflite != null) {
            tflite.close();
            Log.d(TAG, "Interpreter closed");
        }
    }
}
