package com.example.melanoretectai;

import android.annotation.SuppressLint;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class ShowResultActivity extends AppCompatActivity {
TextView txtProbBenign,txtProbMalignant,txtProbLabel;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_result);
//        txtProbBenign = findViewById(R.id.txtprobBenign);
//        txtProbMalignant = findViewById(R.id.txtprobMalignant);
//        txtProbLabel = findViewById(R.id.txtprobLabel);
//        Intent intent = getIntent();
//        if (intent != null) {
//
//            String predictionValues = intent.getStringExtra("PREDICTION_RESULT");
//            String predictedLabel = intent.getStringExtra("PREDICTED_LABEL");
//
//            Log.d("Prediction\t\n", "" + predictionValues + "\n" + predictedLabel);
//
//            if (predictionValues != null && predictedLabel != null) {
//                // Extract the probabilities from the prediction values string
//                String benignProbability = getBenignProbability(predictionValues);
//                String malignantProbability = getMalignantProbability(predictionValues);
//
//                // Set the text for TextViews
//                txtProbBenign.setText(benignProbability);
//                txtProbMalignant.setText(malignantProbability);
//                txtProbLabel.setText(predictedLabel);
//            } else {
//                // Handle case where data is not available
//                txtProbBenign.setText("N/A");
//                txtProbMalignant.setText("N/A");
//                txtProbLabel.setText("No label");
//            }
//        }
    }

        // Helper method to extract benign probability from the string
        private String getBenignProbability(String predictionValues) {
            // Extract the benign probability from the predictionValues string
            String[] parts = predictionValues.replaceAll("[\\[\\]]", "").split(",\\s*");
            return parts.length > 0 ? parts[0] : "N/A";
        }

        // Helper method to extract malignant probability from the string
        private String getMalignantProbability(String predictionValues) {
            // Extract the malignant probability from the predictionValues string
            String[] parts = predictionValues.replaceAll("[\\[\\]]", "").split(",\\s*");
            return parts.length > 1 ? parts[1] : "N/A";
        }

}