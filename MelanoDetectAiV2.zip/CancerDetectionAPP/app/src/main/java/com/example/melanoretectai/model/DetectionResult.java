package com.example.melanoretectai.model;

import androidx.annotation.NonNull;

public class DetectionResult {
    private String id; // Unique identifier for the detection result
    private String userId;
    private String imageUrl; // URL or local path of the scanned image
    private String result;   // Example: "Malignant", "Benign", etc.
    private String confidence; // Example: "95.3%" or "0.953"
    private String dateTime; // ISO or formatted date-time string

    public DetectionResult() {
    }

    public DetectionResult(@NonNull String id, String userId, String imageUrl, String result, String confidence, String dateTime) {
      this.id = id;
        this.userId = userId;
        this.imageUrl = imageUrl;
        this.result = result;
        this.confidence = confidence;
        this.dateTime = dateTime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getConfidence() {
        return confidence;
    }

    public void setConfidence(String confidence) {
        this.confidence = confidence;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }
}
