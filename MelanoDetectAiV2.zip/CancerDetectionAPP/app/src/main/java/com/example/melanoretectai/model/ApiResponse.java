package com.example.melanoretectai.model;

import com.google.gson.annotations.SerializedName;

public class ApiResponse {
    @SerializedName("prediction")
    private float prediction;

    @SerializedName("predicted_class")
    private int predictedClass;

    @SerializedName("result")
    private String result;

    public float getPrediction() {
        return prediction;
    }

    public void setPrediction(float prediction) {
        this.prediction = prediction;
    }

    public int getPredictedClass() {
        return predictedClass;
    }

    public void setPredictedClass(int predictedClass) {
        this.predictedClass = predictedClass;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
