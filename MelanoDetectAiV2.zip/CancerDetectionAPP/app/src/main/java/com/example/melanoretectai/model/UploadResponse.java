package com.example.melanoretectai.model;

public class UploadResponse {
    private String prediction;
    private String predicted_class;
    private String result;

    public String getPrediction() {
        return prediction;
    }

    public String getPredictedClass() {
        return predicted_class;
    }

    public String getResult() {
        return result;
    }
}
